﻿using Microsoft.AspNetCore.Identity;

namespace TaggAlong.Models
{
    public class User : IdentityUser
    {
    }
}